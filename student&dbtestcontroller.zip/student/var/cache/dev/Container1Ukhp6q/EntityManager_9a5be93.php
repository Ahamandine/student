<?php

namespace Container1Ukhp6q;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder9908e = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerc34fd = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties648fb = [
        
    ];

    public function getConnection()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getConnection', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getMetadataFactory', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getExpressionBuilder', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'beginTransaction', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getCache', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getCache();
    }

    public function transactional($func)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'transactional', array('func' => $func), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'wrapInTransaction', array('func' => $func), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'commit', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->commit();
    }

    public function rollback()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'rollback', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getClassMetadata', array('className' => $className), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'createQuery', array('dql' => $dql), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'createNamedQuery', array('name' => $name), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'createQueryBuilder', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'flush', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'clear', array('entityName' => $entityName), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->clear($entityName);
    }

    public function close()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'close', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->close();
    }

    public function persist($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'persist', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'remove', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'refresh', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'detach', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'merge', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getRepository', array('entityName' => $entityName), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'contains', array('entity' => $entity), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getEventManager', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getConfiguration', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'isOpen', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getUnitOfWork', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getProxyFactory', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'initializeObject', array('obj' => $obj), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'getFilters', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'isFiltersStateClean', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'hasFilters', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return $this->valueHolder9908e->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerc34fd = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder9908e) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder9908e = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder9908e->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__get', ['name' => $name], $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        if (isset(self::$publicProperties648fb[$name])) {
            return $this->valueHolder9908e->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9908e;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder9908e;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9908e;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder9908e;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__isset', array('name' => $name), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9908e;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder9908e;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__unset', array('name' => $name), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9908e;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder9908e;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__clone', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        $this->valueHolder9908e = clone $this->valueHolder9908e;
    }

    public function __sleep()
    {
        $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, '__sleep', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;

        return array('valueHolder9908e');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerc34fd = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerc34fd;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerc34fd && ($this->initializerc34fd->__invoke($valueHolder9908e, $this, 'initializeProxy', array(), $this->initializerc34fd) || 1) && $this->valueHolder9908e = $valueHolder9908e;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder9908e;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder9908e;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
