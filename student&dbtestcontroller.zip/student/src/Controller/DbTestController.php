<?php

namespace App\Controller;

use App\Entity\Schoolyear;
use App\Entity\Tag;
use App\Entity\Teacher;
use App\Entity\Project;
use App\Entity\Student;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DbTestController extends AbstractController
{
    #[Route('/db/test/fixtures', name: 'app_db_test_fixtures')]
    public function fixtures(ManagerRegistry $doctrine): Response
    {
        //récupération des repository des schoolyear
        $repository = $doctrine->getRepository(Schoolyear::class);
        $schoolyears = $repository->findAll();
        dump($schoolyears);

        //récupération des repository des tags
        $repository = $doctrine->getRepository(Tag::class);
        $tags = $repository->findAll();
        dump($tags);

        //récupération des repository des teachers
        $repository = $doctrine->getRepository(Teacher::class);
        $teachers = $repository->findAll();
        dump($teachers);

        //récupération des repository des projects
        $repository = $doctrine->getRepository(Project::class);
        $projects = $repository->findAll();
        dump($projects);

        //récupération des repository des students
        $repository = $doctrine->getRepository(Student::class);
        $students = $repository->findAll();
        dump($students);

        exit();

    }

    #[Route('/db/test/orm', name: 'app_db_test_orm')]
    public function orm(ManagerRegistry $doctrine): Response 
    {
        
    }
}

