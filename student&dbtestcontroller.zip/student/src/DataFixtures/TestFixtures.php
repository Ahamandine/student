<?php

namespace App\DataFixtures;

use App\Entity\Project;
use App\Entity\Schoolyear;
use App\Entity\Student;
use App\Entity\Tag;
use App\Entity\Teacher;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory as FakerFactory;
use Faker\Generator as FakerGenerator;

class TestFixtures extends Fixture
{
    //Ajout cours du 19/07/2022 fait pour le projet blog normalement
    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
    }
    //

    public function load(ObjectManager $manager): void
    {
        $faker = FakerFactory::create('fr_FR');

        // $this->loadTag($manager, $faker);
        $this->loadProjects($manager, $faker);
        $this->loadSchoolyears($manager, $faker);
        // $this->loadTeacher($manager, $faker);
        // $this->loadStudent($manager, $faker);
    }

    public function loadProjects(ObjectManager $manager, FakerGenerator $faker)
    {
        $projectNames = [
            'DataBase',
            'Api',
            'Form',
        ];

        foreach ($projectNames as $projectName) {
            $project = new Project();
            $project->setName("Finir {$projectName}");
            $manager->persist($project); 
        }

        for($i = 0; $i < 10; $i++) {
            $project = new Project();
            $project->setName("Finir {$faker->word()}");
            $manager->persist($project);
        }
        
        // @todo récupérer des tags et les coller au hasard

        $manager->flush();
    }
    

    public function loadSchoolyears(ObjectManager $manager, FakerGenerator $faker)
    {
        $schoolyearNames = [
            'Ada Lovelace',
            'Grace Hopper',
            'Margaret Hamilton'
        ];

        foreach ($schoolyearNames as $schoolyearName) {
            $schoolyear = new Schoolyear();
            $schoolyear->setName("Promo {$schoolyearName}");
            $manager->persist($schoolyear); 
        }
    }
}
