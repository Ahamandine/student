<?php

namespace App\Entity;

use App\Repository\TeacherRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TeacherRepository::class)]
class Teacher
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 190)]
    private $name;

    #[ORM\Column(type: 'string', length: 190)]
    private $lastname;

    #[ORM\ManyToMany(targetEntity: Schoolyear::class, inversedBy: 'teachers')]
    private $schoolyears;

    #[ORM\ManyToMany(targetEntity: Tag::class, inversedBy: 'teachers')]
    private $tags;

    public function __construct()
    {
        $this->schoolyears = new ArrayCollection();
        $this->tags = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getLastname(): ?string
    {
        return $this->lastname;
    }

    public function setLastname(string $lastname): self
    {
        $this->lastname = $lastname;

        return $this;
    }

    /**
     * @return Collection<int, Schoolyear>
     */
    public function getSchoolyears(): Collection
    {
        return $this->schoolyears;
    }

    public function addSchoolyear(Schoolyear $schoolyear): self
    {
        if (!$this->schoolyears->contains($schoolyear)) {
            $this->schoolyears[] = $schoolyear;
        }

        return $this;
    }

    public function removeSchoolyear(Schoolyear $schoolyear): self
    {
        $this->schoolyears->removeElement($schoolyear);

        return $this;
    }

    /**
     * @return Collection<int, Tag>
     */
    public function getTags(): Collection
    {
        return $this->tags;
    }

    public function addTag(Tag $tag): self
    {
        if (!$this->tags->contains($tag)) {
            $this->tags[] = $tag;
        }

        return $this;
    }

    public function removeTag(Tag $tag): self
    {
        $this->tags->removeElement($tag);

        return $this;
    }

}
